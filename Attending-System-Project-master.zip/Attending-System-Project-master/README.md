# Attending-System-Project

The system's link https://attendingsystemforartscu.000webhostapp.com/login.php

There are usernames and passwords of users in an officer_user.csv(officer user),a teacher_users.csv(teacher users) and a student_users.csv(student users).The files are in an info_insert_db folder (https://github.com/KEDSARAMAY/Attending-System-Project/tree/master/info_insert_db) 

Report https://drive.google.com/file/d/1Oy07ZSeHoIGtWxjkA8s8iYyScHfMwWMa/view?usp=sharing

Our Team https://drive.google.com/file/d/12TZ66l90Lh6G86U2DqP43oVZUy_QGZuV/view?usp=sharing
